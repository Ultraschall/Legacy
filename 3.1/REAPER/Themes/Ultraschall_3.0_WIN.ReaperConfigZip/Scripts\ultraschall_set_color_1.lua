-- Print Message to console (debugging)
function Msg(val)
	reaper.ShowConsoleMsg(tostring(val).."\n")
end


number = "0"  -- Group Number - change to get a different color

curtheme = reaper.GetLastColorThemeFile()
os = reaper.GetOS()

if (reaper.CountSelectedTracks(0) == 0) then	-- no track selected
	reaper.Main_OnCommand(40296,0) 				-- select all tracks
end
	
file = io.open(curtheme, "r");
	
for line in file:lines() do
  index = string.match(line, "group_(%d+)")  
    if index == number then
    	color_int = string.match(line, "=(%d+)")  
    	if string.match(os, "OSX") then 
    		r, g, b = reaper.ColorFromNative(color_int)
    		color_int = reaper.ColorToNative(b, g, r) -- swap r and b for OSX
    	end
  	 -- Msg(color_int)
		countTracks = reaper.CountSelectedTracks(0)
     -- SELECTED TRACKS LOOP
    	if countTracks > 0 then
      		for j = 0, countTracks-1 do
        	track = reaper.GetSelectedTrack(0, j)
			reaper.SetTrackColor (track, color_int) --set Color to track
  
      		end
    	end
    end
end
