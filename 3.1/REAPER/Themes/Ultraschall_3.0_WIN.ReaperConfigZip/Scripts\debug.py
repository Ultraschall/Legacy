RPR_APITest()
