-- Print Message to console (debugging)
function Msg(val)
	reaper.ShowConsoleMsg(tostring(val).."\n")
end


number = "0"  -- Group Number - change to get a different color

curtheme = reaper.GetLastColorThemeFile()
	
file = io.open(curtheme, "r");
	
for line in file:lines() do
	index = string.match(line, "group_(%d+)")	
    if index == number then
    	color_int = string.match(line, "=(%d+)")	
    	-- Msg(wert)

		countTracks = reaper.CountSelectedTracks(0)
		-- SELECTED TRACKS LOOP
		if countTracks > 0 then
			for j = 0, countTracks-1 do
				track = reaper.GetSelectedTrack(0, j)

 				B = math.floor(color_int / 65536)
 				G = math.floor((color_int - B * 65536) / 256)
 				R = math.floor(color_int - B * 65536 - G * 256)
				color_hex = "0x1"..(string.format("%02x", R))..(string.format("%02x", G))..(string.format("%02x", B))
				
				-- Msg(color_int)
				-- Msg(R)
				-- Msg(G)
				-- Msg(B)
				-- Msg(color_hex)

				reaper.SetMediaTrackInfo_Value(track, "I_CUSTOMCOLOR", color_hex)
			end
		end
    end
end
